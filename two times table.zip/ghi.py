A=2
B=3
C=A+B
print(C)