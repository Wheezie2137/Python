temp=input("Enter today's temperature:")
if float(temp)>30:
    print("It's hot today!")
if float(temp)<30:
    print("It's cold today!")
if float(temp) ==30:
    print("Nice weather we're having!")