A=1
while A<=10:
    B=1
        while B<=10:
        print("B")
        B=B+1
    A=A+1
