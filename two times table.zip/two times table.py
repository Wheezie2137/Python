i=1
while i<=10:
    print(2,"x",i,"=",(i*2))
    i=i+1
    