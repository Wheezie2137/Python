a=1
while a<=37:
    print(a,"Louise")
    a=a+1

