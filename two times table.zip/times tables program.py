i=1
T=int(input("Which multiplication table do you need?"))
while i<=10:
    print(i,"x",T,"=",(T*i))
    i=i+1