salary=int(input("Enter your salary:"))
if salary>=1000:
    print("A")
    if salary>=2000:
        print("C")
    else:
        print("D")
else:
    print("B")
    if salary>=500:
        print("E")
    else:
        print("F")
print("G")
