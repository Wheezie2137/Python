A=8
B=2
C=A+B
print(C)